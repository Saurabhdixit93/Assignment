module.exports.home = (req, res) => {
  return res.send(`<h2>Polling System Api</h2>
  <a href="https://github.com/manikpokhetra79/PollingSystem_APi">Vist Gihub Repository to read on How to use this API.</a>
  `);
};
